package com.localhost.host

import android.content.Context
import android.net.Uri
import android.webkit.MimeTypeMap
import androidx.documentfile.provider.DocumentFile
import fi.iki.elonen.NanoHTTPD
import java.io.InputStream
import java.util.Locale

class WebServer(
    private val ctx: Context,
    private val root: DocumentFile,
    port: Int
) : NanoHTTPD(port) {

    @Volatile
    var hits = 0L

    override fun serve(session: IHTTPSession): Response {
        hits++
        if (session.method != Method.GET && session.method != Method.HEAD) {
            return text(Response.Status.METHOD_NOT_ALLOWED, "Method not allowed")
        }
        val clean = Uri.decode(session.uri.substringBefore('?'))
        val parts = clean.split('/').filter { it.isNotEmpty() }
        if (parts.any { it == ".." || it == "." }) {
            return text(Response.Status.FORBIDDEN, "Forbidden")
        }

        var node: DocumentFile? = root
        for (p in parts) node = node?.findFile(p)
        if (node != null && node.isDirectory) node = node.findFile("index.html")
        if (node == null || !node.isFile) return notFound()

        return try {
            fileResponse(node, session)
        } catch (e: Exception) {
            text(Response.Status.INTERNAL_ERROR, "Server error")
        }
    }

    private fun fileResponse(f: DocumentFile, session: IHTTPSession): Response {
        val mime = mimeOf(f.name ?: "")
        val len = f.length()
        val range = session.headers["range"]

        if (range != null && range.startsWith("bytes=") && len > 0) {
            val r = range.removePrefix("bytes=").substringBefore(',').split("-")
            var start: Long
            var end: Long
            if (r[0].isEmpty()) {
                val n = r.getOrNull(1)?.toLongOrNull() ?: 0L
                start = maxOf(0L, len - n)
                end = len - 1
            } else {
                start = r[0].toLongOrNull() ?: 0L
                end = r.getOrNull(1)?.toLongOrNull() ?: (len - 1)
            }
            if (start >= len || start > end) {
                val bad = text(Response.Status.RANGE_NOT_SATISFIABLE, "")
                bad.addHeader("Content-Range", "bytes */$len")
                return bad
            }
            end = minOf(end, len - 1)
            val ins = open(f)
            var toSkip = start
            while (toSkip > 0) {
                val k = ins.skip(toSkip)
                if (k <= 0) break
                toSkip -= k
            }
            val resp = newFixedLengthResponse(Response.Status.PARTIAL_CONTENT, mime, ins, end - start + 1)
            resp.addHeader("Content-Range", "bytes $start-$end/$len")
            resp.addHeader("Accept-Ranges", "bytes")
            resp.addHeader("Cache-Control", "no-cache")
            return resp
        }

        val resp = newFixedLengthResponse(Response.Status.OK, mime, open(f), len)
        resp.addHeader("Accept-Ranges", "bytes")
        resp.addHeader("Cache-Control", "no-cache")
        return resp
    }

    private fun open(f: DocumentFile): InputStream =
        ctx.contentResolver.openInputStream(f.uri) ?: throw IllegalStateException("cannot open")

    private fun notFound(): Response {
        val page = root.findFile("404.html")
        if (page != null && page.isFile) {
            return try {
                newFixedLengthResponse(Response.Status.NOT_FOUND, "text/html; charset=utf-8", open(page), page.length())
            } catch (e: Exception) {
                text(Response.Status.NOT_FOUND, "404 Not Found")
            }
        }
        return text(Response.Status.NOT_FOUND, "404 Not Found")
    }

    private fun text(status: Response.IStatus, msg: String): Response =
        newFixedLengthResponse(status, "text/plain; charset=utf-8", msg)

    private fun mimeOf(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
        val fixed = when (ext) {
            "html", "htm" -> "text/html; charset=utf-8"
            "css" -> "text/css; charset=utf-8"
            "js", "mjs" -> "text/javascript; charset=utf-8"
            "json", "webmanifest" -> "application/json; charset=utf-8"
            "svg" -> "image/svg+xml"
            "wasm" -> "application/wasm"
            "woff" -> "font/woff"
            "woff2" -> "font/woff2"
            "ttf" -> "font/ttf"
            "otf" -> "font/otf"
            "mp4" -> "video/mp4"
            "webm" -> "video/webm"
            "mp3" -> "audio/mpeg"
            "txt" -> "text/plain; charset=utf-8"
            else -> null
        }
        if (fixed != null) return fixed
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }
}

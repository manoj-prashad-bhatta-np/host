package com.localhost.host

import java.net.Inet4Address
import java.net.InetAddress
import java.net.NetworkInterface

object Net {
    /** Phone's current Wi-Fi / hotspot IPv4 address (display + mDNS binding only). */
    fun localIPv4(): InetAddress? {
        return try {
            val all = NetworkInterface.getNetworkInterfaces().toList()
                .filter { it.isUp && !it.isLoopback }
            val preferred = all.filter {
                val n = it.name.lowercase()
                n.startsWith("wlan") || n.startsWith("ap") || n.startsWith("swlan") || n.startsWith("eth")
            }
            (preferred + all).firstNotNullOfOrNull { ni ->
                ni.inetAddresses.toList().firstOrNull { it is Inet4Address && it.isSiteLocalAddress }
            }
        } catch (e: Exception) {
            null
        }
    }
}

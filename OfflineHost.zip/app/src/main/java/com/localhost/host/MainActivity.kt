package com.localhost.host

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val fixedLink = "http://${BuildConfig.SITE_HOST}:${BuildConfig.SITE_PORT}"
    private lateinit var folderText: TextView
    private lateinit var statusText: TextView
    private lateinit var toggle: Button
    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 1000)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        setOnClickListener { onClick() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
        }

        col.addView(TextView(this).apply { text = "Offline Host"; textSize = 26f })
        col.addView(TextView(this).apply {
            text = "Your fixed link (use this for your QR code):"
            setPadding(0, dp(20), 0, dp(4))
        })
        col.addView(TextView(this).apply {
            text = fixedLink
            textSize = 20f
            setTextIsSelectable(true)
        })
        col.addView(button("Copy link") {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("link", fixedLink))
            Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
        })

        folderText = TextView(this).apply { setPadding(0, dp(20), 0, dp(4)) }
        col.addView(folderText)
        col.addView(button("Choose site folder") { pickFolder() })

        toggle = button("Start hosting") { toggleHosting() }
        col.addView(toggle)

        statusText = TextView(this).apply { setPadding(0, dp(20), 0, 0) }
        col.addView(statusText)

        col.addView(button("Keep running in background") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })

        col.gravity = Gravity.START
        setContentView(ScrollView(this).apply { addView(col) })

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        handler.post(ticker)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }

    @Suppress("DEPRECATION")
    private fun pickFolder() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION or
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or
                Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
        )
        startActivityForResult(i, 1)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            getSharedPreferences(HostService.PREFS, MODE_PRIVATE)
                .edit().putString(HostService.KEY_TREE, uri.toString()).apply()
            if (HostService.running()) {
                Toast.makeText(this, "Stop and start hosting to use the new folder", Toast.LENGTH_LONG).show()
            }
            refresh()
        }
    }

    private fun toggleHosting() {
        if (HostService.running()) {
            startService(Intent(this, HostService::class.java).setAction(HostService.ACTION_STOP))
        } else {
            val tree = getSharedPreferences(HostService.PREFS, MODE_PRIVATE)
                .getString(HostService.KEY_TREE, null)
            if (tree == null) {
                Toast.makeText(this, "Choose a site folder first", Toast.LENGTH_SHORT).show()
                return
            }
            val i = Intent(this, HostService::class.java)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        }
        handler.postDelayed({ refresh() }, 400)
    }

    private fun refresh() {
        val tree = getSharedPreferences(HostService.PREFS, MODE_PRIVATE)
            .getString(HostService.KEY_TREE, null)
        folderText.text = if (tree == null) "Site folder: not chosen"
        else "Site folder: " + Uri.decode(tree).substringAfterLast(':')

        val running = HostService.running()
        toggle.text = if (running) "Stop hosting" else "Start hosting"

        val ip = Net.localIPv4()?.hostAddress
        val sb = StringBuilder()
        sb.append(if (running) "Status: HOSTING\n" else "Status: stopped\n")
        if (running) {
            sb.append("Requests served: ${HostService.server?.hits ?: 0}\n")
        }
        HostService.lastError?.let { sb.append("Error: $it\n") }
        sb.append("\nBackup link, for testing only (can change): ")
        sb.append(if (ip != null) "http://$ip:${BuildConfig.SITE_PORT}" else "no Wi-Fi/hotspot detected")
        statusText.text = sb.toString()
    }
}

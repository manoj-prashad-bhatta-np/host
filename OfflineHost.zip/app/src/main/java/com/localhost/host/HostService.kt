package com.localhost.host

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.documentfile.provider.DocumentFile
import fi.iki.elonen.NanoHTTPD
import java.io.IOException
import javax.jmdns.JmDNS
import javax.jmdns.ServiceInfo as MdnsInfo

class HostService : Service() {

    companion object {
        const val ACTION_STOP = "com.localhost.host.STOP"
        const val PREFS = "prefs"
        const val KEY_TREE = "tree"
        private const val CHANNEL = "host"

        @Volatile var server: WebServer? = null
        @Volatile var lastError: String? = null
        fun running() = server != null
    }

    private var wake: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var mcLock: WifiManager.MulticastLock? = null
    private var jmdns: JmDNS? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            shutdown()
            stopSelf()
            return START_NOT_STICKY
        }
        startFg()
        if (server == null) {
            lastError = null
            val tree = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_TREE, null)
            val root = tree?.let { DocumentFile.fromTreeUri(this, Uri.parse(it)) }
            if (root == null || !root.canRead()) {
                lastError = "Choose a site folder first."
                stopSelf()
                return START_NOT_STICKY
            }
            try {
                val s = WebServer(applicationContext, root, BuildConfig.SITE_PORT)
                s.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false)
                server = s
            } catch (e: IOException) {
                lastError = "Cannot start on port ${BuildConfig.SITE_PORT}: ${e.message}"
                stopSelf()
                return START_NOT_STICKY
            }
            acquireLocks()
            startMdns()
        }
        return START_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Hosting", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL)
        else @Suppress("DEPRECATION") Notification.Builder(this)
        val n = b.setContentTitle("Hosting your website")
            .setContentText("http://${BuildConfig.SITE_HOST}:${BuildConfig.SITE_PORT}")
            .setSmallIcon(android.R.drawable.ic_menu_share)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun acquireLocks() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "host:wake").apply {
            setReferenceCounted(false); acquire()
        }
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val mode = if (Build.VERSION.SDK_INT >= 29) WifiManager.WIFI_MODE_FULL_LOW_LATENCY
        else @Suppress("DEPRECATION") WifiManager.WIFI_MODE_FULL_HIGH_PERF
        wifiLock = wm.createWifiLock(mode, "host:wifi").apply {
            setReferenceCounted(false); acquire()
        }
        mcLock = wm.createMulticastLock("host:mc").apply {
            setReferenceCounted(false); acquire()
        }
    }

    private fun startMdns() {
        val host = BuildConfig.SITE_HOST
        val name = if (host.endsWith(".local")) host.removeSuffix(".local") else "myapp"
        Thread {
            try {
                val ip = Net.localIPv4() ?: return@Thread
                val j = JmDNS.create(ip, name)
                j.registerService(
                    MdnsInfo.create("_http._tcp.local.", name, BuildConfig.SITE_PORT, "path=/")
                )
                jmdns = j
            } catch (e: Exception) {
                // mDNS is optional; the server keeps working without it.
            }
        }.start()
    }

    private fun shutdown() {
        server?.stop()
        server = null
        val j = jmdns
        jmdns = null
        Thread {
            try { j?.unregisterAllServices(); j?.close() } catch (_: Exception) {}
        }.start()
        try { wake?.release() } catch (_: Exception) {}
        try { wifiLock?.release() } catch (_: Exception) {}
        try { mcLock?.release() } catch (_: Exception) {}
        wake = null; wifiLock = null; mcLock = null
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }
}

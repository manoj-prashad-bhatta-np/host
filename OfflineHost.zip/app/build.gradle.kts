plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val siteHost = (project.findProperty("SITE_HOST") as String?) ?: "myapp.local"
val sitePort = (project.findProperty("SITE_PORT") as String?) ?: "8080"

android {
    namespace = "com.localhost.host"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.localhost.host"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        buildConfigField("String", "SITE_HOST", "\"$siteHost\"")
        buildConfigField("int", "SITE_PORT", sitePort)
    }

    buildFeatures { buildConfig = true }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    packaging {
        resources {
            excludes += setOf(
                "META-INF/INDEX.LIST", "META-INF/DEPENDENCIES",
                "META-INF/LICENSE*", "META-INF/NOTICE*", "META-INF/*.kotlin_module"
            )
        }
    }
}

dependencies {
    implementation("org.nanohttpd:nanohttpd:2.3.1")
    implementation("org.jmdns:jmdns:3.5.9")
    implementation("androidx.documentfile:documentfile:1.0.1")
}

1. Edit gradle.properties: set SITE_HOST and SITE_PORT (this is your fixed link).
2. Upload ALL files (including the .github folder) to a GitHub repo, branch main.
3. Actions tab -> "Build APK" -> download artifact "OfflineHost-APK" -> install the .apk.
4. In the app: Choose site folder -> Start hosting. Make your QR from the fixed link.
